<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Mobil-Mobilan — HTML5 Canvas Game</title>
  <style>
    :root{--bg:#0b1220;--road:#2b2b2b;--stripe:#f2f2f2}
    html,body{height:100%;margin:0;background:linear-gradient(180deg,#071029 0%, #0b1220 60%, #072033 100%);font-family:Inter, system-ui, Arial}
    #gameWrap{display:flex;align-items:center;justify-content:center;height:100vh}
    canvas{background:transparent;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.6);max-width:96vw;max-height:96vh}
    .ui{position:fixed;left:16px;top:16px;color:#fff;z-index:20}
    .ui button{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);color:#fff;padding:8px 12px;border-radius:8px;margin-right:8px}
    .score{position:fixed;right:16px;top:16px;color:#fff;font-weight:700;font-size:18px;background:rgba(0,0,0,.25);padding:8px 12px;border-radius:10px}
    .centerMsg{position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);color:#fff;text-align:center}
    .centerMsg button{margin-top:12px}
    @media (max-width:640px){.ui{left:8px;top:auto;bottom:8px}}
  </style>
</head>
<body>
  <div id="gameWrap">
    <canvas id="game"></canvas>
  </div>
  <div class="ui">
    <button id="startBtn">Mulai</button>
    <button id="pauseBtn">Pause</button>
    <button id="restartBtn">Restart</button>
  </div>
  <div class="score" id="score">Skor: 0</div>
  <div class="centerMsg" id="msg"></div>

<script>
/*
  Mobil-Mobilan: Single-file HTML5 canvas game
  - Vector "HD" drawing (no external assets)
  - Keyboard + touch support
  - Responsive scaling
  - Parallax background, obstacles, particle effects
*/

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
let DPR = Math.min(window.devicePixelRatio || 1, 2);

// virtual resolution (will scale to canvas size)
const VIRTUAL_W = 900;
const VIRTUAL_H = 1600;

function resize(){
  const maxW = Math.min(window.innerWidth * 0.96, 540);
  const maxH = Math.min(window.innerHeight * 0.96, 920);
  // prefer portrait height for mobile, landscape for desktop
  const ratio = VIRTUAL_W / VIRTUAL_H;
  let w = Math.min(maxW, maxH * ratio);
  let h = Math.min(maxH, maxW / ratio);
  canvas.style.width = w + 'px';
  canvas.style.height = h + 'px';
  canvas.width = Math.round(w * DPR);
  canvas.height = Math.round(h * DPR);
  ctx.setTransform(DPR * (canvas.width / (DPR * w)), 0, 0, DPR * (canvas.height / (DPR * h)), 0, 0);
}
window.addEventListener('resize', resize);
resize();

// Game state
let lastTime=0, delta=0;
let speedMultiplier = 1;
let running=false;
let paused=false;
let score=0;
let highScore=0;
let player;
let obstacles=[];
let particles=[];
let laneCount=3;
let laneWidth;
let spawnTimer=0;
let difficultyTimer=0;

// Controls
const keys = {left: false, right:false};
window.addEventListener('keydown', e=>{
  if(e.key==='ArrowLeft' || e.key==='a') keys.left=true;
  if(e.key==='ArrowRight' || e.key==='d') keys.right=true;
  if(e.key===' '){ togglePause(); }
});
window.addEventListener('keyup', e=>{
  if(e.key==='ArrowLeft' || e.key==='a') keys.left=false;
  if(e.key==='ArrowRight' || e.key==='d') keys.right=false;
});

// Touch controls: simple left/right halves
canvas.addEventListener('pointerdown', e=>{
  const rect = canvas.getBoundingClientRect();
  const x = (e.clientX - rect.left) / rect.width * canvas.width / DPR;
  if(x < canvas.width / (2*DPR)) keys.left = true; else keys.right = true;
});
canvas.addEventListener('pointerup', e=>{ keys.left=false; keys.right=false; });

// Utility
function rand(a,b){ return Math.random()*(b-a)+a }

// Player car
function createPlayer(){
  return {
    lane:1,
    x:0,
    y: VIRTUAL_H - 300,
    width: 120,
    height: 220,
    targetX:0,
    speed: 8,
    colorTop: '#ff5252',
    colorBottom:'#b71c1c',
  }
}

// Obstacles (other cars)
function spawnObstacle(){
  const lane = Math.floor(rand(0,laneCount));
  const w = 110;
  const h = 210;
  const speed = rand(4.5,8) * speedMultiplier;
  obstacles.push({lane,w,h,x:laneCenter(lane) - w/2,y:-h - 20,speed,colorTop:randomColor(),colorBottom:darker()});
}

function randomColor(){
  const palette = ['#ff8a65','#4db6ac','#81d4fa','#ffd54f','#ce93d8','#a5d6a7'];
  return palette[Math.floor(Math.random()*palette.length)];
}
function darker(){ return '#333' }

function laneCenter(i){
  const roadLeft = (VIRTUAL_W - laneWidth*laneCount)/2;
  return roadLeft + i*laneWidth + laneWidth/2;
}

// Particles for sparks
function spawnParticles(x,y,count){
  for(let i=0;i<count;i++) particles.push({x,y,vx:rand(-3,3),vy:rand(-6,-1),life:rand(30,70),age:0,r:rand(2,6)})
}

// Main init
function init(){
  laneWidth = Math.min(240, Math.floor(VIRTUAL_W*0.18));
  player = createPlayer();
  player.x = laneCenter(player.lane) - player.width/2;
  obstacles = [];
  particles = [];
  score = 0;
  spawnTimer = 0;
  difficultyTimer = 0;
}

// Game loop
function update(dt){
  if(paused) return;
  difficultyTimer += dt;
  score += dt * 0.06 * speedMultiplier;
  spawnTimer += dt;
  // increase difficulty over time
  if(difficultyTimer > 5000){ speedMultiplier += 0.05; difficultyTimer = 0; }
  // spawn obstacles
  if(spawnTimer > Math.max(600 - speedMultiplier*60, 260)){
    spawnObstacle(); spawnTimer = 0;
  }
  // player control: lane-based smooth movement
  if(keys.left){ player.lane = Math.max(0, player.lane-1); keys.left=false }
  if(keys.right){ player.lane = Math.min(laneCount-1, player.lane+1); keys.right=false }
  player.targetX = laneCenter(player.lane) - player.width/2;
  // smooth transition
  player.x += (player.targetX - player.x) * 0.18;
  // update obstacles
  for(let i=obstacles.length-1;i>=0;i--){
    const o = obstacles[i];
    o.y += o.speed * (1 + Math.min(score/1000,2));
    if(o.y > VIRTUAL_H + 200){ obstacles.splice(i,1); continue }
    // collision check
    if(o.y + o.h > player.y + 40 && o.y < player.y + player.height - 20){
      if(o.x < player.x + player.width - 20 && o.x + o.w - 20 > player.x){
        // collision!
        spawnParticles(player.x + player.width/2, player.y + player.height/2, 18);
        running=false; paused=true; showMessage('Kecelakaan! Skor: ' + Math.floor(score));
      }
    }
  }
  // particles
  for(let i=particles.length-1;i>=0;i--){
    const p = particles[i]; p.vy += 0.2; p.x += p.vx; p.y += p.vy; p.age+=1; if(p.age > p.life) particles.splice(i,1);
  }
}

// Drawing: HD-style with gradients and crisp lines
function draw(){
  // clear
  ctx.clearRect(0,0,VIRTUAL_W,VIRTUAL_H);
  // sky gradient
  const gSky = ctx.createLinearGradient(0,0,0,VIRTUAL_H*0.5);
  gSky.addColorStop(0,'#062031'); gSky.addColorStop(1,'#052034');
  ctx.fillStyle = gSky; ctx.fillRect(0,0,VIRTUAL_W,VIRTUAL_H);

  // distant mountains / city