<?php
require 'koneksi.php';
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Cari Barang</title></head><body>
  <h2>Cari Barang</h2>
  <form method="get" action="search.php">
    <input type="text" name="q" placeholder="Masukkan kata kunci kode/nama" value="<?php echo htmlspecialchars($q); ?>">
    <button type="submit">Cari</button>
  </form>

  <?php if ($q !== ''): 
    $like = '%' . $q . '%';
    $sql = "SELECT * FROM barang WHERE kode LIKE ? OR nama_barang LIKE ? ORDER BY kode";
    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $like, $like);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
  ?>
    <h3>Hasil Pencarian untuk "<?php echo htmlspecialchars($q); ?>"</h3>
    <table border="1" cellpadding="6" cellspacing="0">
      <tr><th>Kode</th><th>Nama</th><th>Harga</th><th>Aksi</th></tr>
      <?php if ($res && mysqli_num_rows($res) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($res)): ?>
          <tr>
            <td><?php echo htmlspecialchars($row['kode']); ?></td>
            <td><?php echo htmlspecialchars($row['nama_barang']); ?></td>
            <td style="text-align:right;"><?php echo number_format($row['harga'],0,',','.'); ?></td>
            <td>
              <a href="edit.php?kode=<?php echo urlencode($row['kode']); ?>">Edit</a>
              |
              <a href="delete.php?kode=<?php echo urlencode($row['kode']); ?>" onclick="return confirm('Yakin?')">Delete</a>
            </td>
          </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="4">Tidak ditemukan.</td></tr>
      <?php endif; ?>
    </table>
  <?php endif; ?>
  <p><a href="index.php">Kembali</a></p>
</body></html>
