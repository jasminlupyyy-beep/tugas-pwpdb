<?php
$hostname = "localhost";
$database = "dbbarang";
$username = "root";
$password = "";

// membuat koneksi
$koneksi = mysqli_connect($hostname, $username, $password, $database);

// cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
