<?php 
require 'koneksi.php'; 
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Data Barang</title>
  <style>
    table { border-collapse: collapse; width: 80%; }
    th, td { border: 1px solid #ccc; padding: 8px; }
    th { background:#f0f0f0; }
  </style>
</head>
<body>
  <h2>Data Barang</h2>

  <p>
    <a href="insert.php">+ Add Barang</a>
  </p>

  <form method="get" action="index.php" style="margin-bottom:12px;">
    <input type="text" name="q" placeholder="Cari kode atau nama..." value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q']) : ''; ?>">
    <button type="submit">Cari</button>
    <a href="index.php">Reset</a>
  </form>

  <?php
  // Pencarian (jika ada)
  $q = isset($_GET['q']) ? trim($_GET['q']) : '';
  if ($q !== '') {
      // cari berdasarkan kode atau nama_barang
      $like = '%' . $q . '%';
      $sql = "SELECT * FROM barang WHERE kode LIKE ? OR nama_barang LIKE ? ORDER BY kode";
      $stmt = mysqli_prepare($koneksi, $sql);
      mysqli_stmt_bind_param($stmt, "ss", $like, $like);
      mysqli_stmt_execute($stmt);
      $res = mysqli_query($koneksi, "SELECT * FROM barang ORDER BY kode");
  } else {
      $res = mysqli_query($koneksi, "SELECT * FROM barang ORDER BY kode");
  }
  ?>

  <table>
    <tr>
      <th>Kode Barang</th>
      <th>Nama Barang</th>
      <th>Harga (Rp)</th>
      <th>Aksi</th>
    </tr>

    <?php if ($res && mysqli_num_rows($res) > 0): ?>
      <?php while ($row = mysqli_fetch_assoc($res)): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['kode']); ?></td>
          <td><?php echo htmlspecialchars($row['nama_barang']); ?></td>
          <td style="text-align:right;"><?php echo number_format($row['harga'],0,',','.'); ?></td>
          <td>
            <a href="edit.php?kode=<?php echo urlencode($row['kode']); ?>">Edit</a> |
            <a href="delete.php?kode=<?php echo urlencode($row['kode']); ?>" onclick="return confirm('Yakin ingin menghapus <?php echo addslashes($row['nama_barang']); ?>?')">Delete</a>
          </td>
        </tr>
      <?php endwhile; ?>
    <?php else: ?>
      <tr><td colspan="4" style="text-align:center;">Tidak ada data.</td></tr>
    <?php endif; ?>
  </table>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'added'): ?>
    <p style="color:green;">Data berhasil ditambahkan.</p>
  <?php endif; ?>

</body>
</html>
